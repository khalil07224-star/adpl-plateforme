-- ADMB : prise en charge des cotisations en XOF et GNF
-- À EXÉCUTER MANUELLEMENT dans Supabase > SQL Editor, après sauvegarde.
-- Ce script ne supprime aucune cotisation ni aucun membre.

ALTER TABLE public.cotisations
  ADD COLUMN IF NOT EXISTS devise text;

-- Les cotisations historiques (s'il y en avait) sont classées en XOF.
-- L'utilisateur a indiqué qu'aucune cotisation n'a encore été enregistrée.
UPDATE public.cotisations
SET devise = 'XOF'
WHERE devise IS NULL;

ALTER TABLE public.cotisations
  ALTER COLUMN devise SET DEFAULT 'XOF',
  ALTER COLUMN devise SET NOT NULL;

-- Supprime uniquement l'ancienne unicité membre/année/mois, si elle existe,
-- afin de permettre une ligne XOF et une ligne GNF pour la même période.
DO $$
DECLARE
  old_constraint record;
  old_index record;
BEGIN
  FOR old_constraint IN
    SELECT c.conname
    FROM pg_constraint c
    WHERE c.conrelid = 'public.cotisations'::regclass
      AND c.contype = 'u'
      AND (
        SELECT array_agg(a.attname::text ORDER BY a.attname::text)
        FROM unnest(c.conkey) AS k(attnum)
        JOIN pg_attribute a
          ON a.attrelid = c.conrelid AND a.attnum = k.attnum
      ) = ARRAY['annee','membre_id','mois']::text[]
  LOOP
    EXECUTE format('ALTER TABLE public.cotisations DROP CONSTRAINT %I', old_constraint.conname);
  END LOOP;

  -- Gère aussi le cas où l'ancienne unicité aurait été créée comme index autonome.
  FOR old_index IN
    SELECT ns.nspname AS schema_name, idx.relname AS index_name
    FROM pg_index i
    JOIN pg_class tbl ON tbl.oid = i.indrelid
    JOIN pg_namespace tn ON tn.oid = tbl.relnamespace
    JOIN pg_class idx ON idx.oid = i.indexrelid
    JOIN pg_namespace ns ON ns.oid = idx.relnamespace
    WHERE tn.nspname = 'public'
      AND tbl.relname = 'cotisations'
      AND i.indisunique
      AND NOT i.indisprimary
      AND NOT EXISTS (SELECT 1 FROM pg_constraint c WHERE c.conindid = i.indexrelid)
      AND i.indnkeyatts = 3
      AND (
        SELECT array_agg(a.attname::text ORDER BY a.attname::text)
        FROM unnest(i.indkey) WITH ORDINALITY AS k(attnum, ord)
        JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = k.attnum
        WHERE k.ord <= i.indnkeyatts
      ) = ARRAY['annee','membre_id','mois']::text[]
  LOOP
    EXECUTE format('DROP INDEX %I.%I', old_index.schema_name, old_index.index_name);
  END LOOP;
END $$;

-- Un seul enregistrement par membre, année, mois et devise.
CREATE UNIQUE INDEX IF NOT EXISTS cotisations_membre_annee_mois_devise_uidx
  ON public.cotisations (membre_id, annee, mois, devise);

-- Valeurs de devise autorisées.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.cotisations'::regclass
      AND conname = 'cotisations_devise_check'
  ) THEN
    ALTER TABLE public.cotisations
      ADD CONSTRAINT cotisations_devise_check
      CHECK (devise IN ('XOF', 'GNF'));
  END IF;
END $$;

-- Vérification finale : la colonne devise doit être NOT NULL et l'index doit exister.
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'cotisations'
  AND column_name = 'devise';

SELECT indexname, indexdef
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename = 'cotisations'
  AND indexname = 'cotisations_membre_annee_mois_devise_uidx';
