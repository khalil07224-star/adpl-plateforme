PLATEFORME ADMB — VERSION 4 : COTISATION UNIQUE, DEUX AFFICHAGES MONÉTAIRES

Fichiers :
- index.html : plateforme publique, registre et espace de gestion intégré.
- admin.html : page de connexion administrateur de la version précédente.
- ADMB_logo.png : logo officiel intégré à la plateforme.
- MIGRATION_XOF_GNF.sql : migration précédente qui a ajouté devise et l'index multi-devise.
- MIGRATION_UN_PAIEMENT_DEUX_MONNAIES.sql : migration complémentaire requise pour revenir à une seule ligne de cotisation par membre, année et mois.

RÈGLE DE CONVERSION ADMB
1 XOF = 15 GNF.

FONCTIONNEMENT DANS CETTE VERSION
- L'administrateur saisit le montant dans la colonne XOF ou GNF.
- L'autre montant se calcule automatiquement.
- Une seule ligne est envoyée à Supabase : le montant saisi et sa devise d'origine.
- Les tableaux, totaux annuels, consultation, export CSV et reçus affichent les deux équivalents.
- Les deux montants affichés sont le même total dans deux unités ; ils ne sont jamais additionnés.
- Les conversions XOF peuvent afficher jusqu'à 8 décimales.
- Une cotisation déjà enregistrée en XOF reste en XOF ; son équivalent GNF est calculé à l'affichage.

INSTALLATION SUPABASE
La première migration XOF/GNF a déjà été exécutée selon les étapes précédentes.
Avant d'utiliser cette version, exécuter dans Supabase SQL Editor le fichier :
MIGRATION_UN_PAIEMENT_DEUX_MONNAIES.sql
Cette migration vérifie qu'il n'existe pas de doublons pour un même membre, une même année et un même mois. Elle s'arrête sans effectuer la modification si elle détecte des doublons ou une devise invalide.

IMPORTANT
- Ne pas exécuter à nouveau MIGRATION_XOF_GNF.sql : elle a déjà été appliquée.
- La migration complémentaire ne supprime aucune cotisation ; elle modifie uniquement l'index d'unicité.
- La plateforme nécessite une connexion Internet et utilise le projet Supabase déjà configuré dans le code.
- Cette version ne modifie pas les tables Membres ni les comptes administrateurs.
- La consultation publique des données de membres doit encore faire l'objet d'un renforcement de sécurité avant une mise en production ouverte.
