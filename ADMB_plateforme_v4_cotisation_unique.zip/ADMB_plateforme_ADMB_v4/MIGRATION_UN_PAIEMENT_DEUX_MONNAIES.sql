-- ADMB : une seule cotisation par membre, année et mois.
-- Les deux montants XOF/GNF sont des équivalents d'affichage ;
-- un seul montant et une seule devise sont enregistrés dans cotisations.
-- Taux appliqué par l'interface : 1 XOF = 15 GNF.

BEGIN;

DO $$
BEGIN
  -- Vérifier que la devise est renseignée et autorisée.
  IF EXISTS (
    SELECT 1 FROM public.cotisations
    WHERE devise IS NULL OR devise NOT IN ('XOF', 'GNF')
  ) THEN
    RAISE EXCEPTION 'Migration arrêtée : devise absente ou invalide dans cotisations.';
  END IF;

  -- Refuser la migration si des doublons existent déjà pour un même mois.
  IF EXISTS (
    SELECT 1
    FROM public.cotisations
    GROUP BY membre_id, annee, mois
    HAVING COUNT(*) > 1
  ) THEN
    RAISE EXCEPTION 'Migration arrêtée : plusieurs cotisations existent pour un même membre, année et mois. Vérifiez-les avant de continuer.';
  END IF;
END $$;

-- Retirer l'index qui autorisait une ligne XOF et une ligne GNF
-- pour le même mois.
DROP INDEX IF EXISTS public.cotisations_membre_annee_mois_devise_key;

-- Réimposer une seule ligne de cotisation par membre et par mois.
CREATE UNIQUE INDEX IF NOT EXISTS cotisations_membre_annee_mois_unique
ON public.cotisations (membre_id, annee, mois);

COMMIT;
